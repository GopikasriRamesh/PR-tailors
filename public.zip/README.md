PR-tailors
A fully responsive and scroll-interactive portfolio website built with React, Tailwind CSS, and Framer Motion — inspired by the PR-TAILOR Figma design. It features smooth navigation, animated transitions, a mobile-first layout, and modular components.

